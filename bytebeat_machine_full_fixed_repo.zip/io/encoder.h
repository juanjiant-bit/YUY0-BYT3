#pragma once
#include <stdint.h>
#include "pico/types.h"

class Encoder {
public:
    void init(uint pin_a, uint pin_b, uint pin_sw);
    void update();
    int  read_delta();
    bool read_click();

private:
    uint pin_a_ = 0;
    uint pin_b_ = 0;
    uint pin_sw_ = 0;

    int  last_state_ = 0;
    int  delta_      = 0;
    bool last_sw_    = false;
    bool click_      = false;
};
