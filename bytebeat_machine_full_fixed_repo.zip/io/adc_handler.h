#pragma once
// adc_handler.h — Bytebeat Machine V1.10
// CAMBIOS: NUM_POTS 5 → 6. Pot 5 = CH5 del 74HC4051 (ENV_RELEASE/ATTACK).
#include <cstdint>

class AdcHandler {
public:
    static constexpr uint8_t  NUM_POTS = 6;   // V1.10: pot 5 = envelope
    static constexpr uint8_t  MUX_S0  = 2;
    static constexpr uint8_t  MUX_S1  = 3;
    static constexpr uint8_t  MUX_S2  = 4;
    static constexpr uint8_t  ADC_PIN = 26;
    static constexpr float    SMOOTH  = 0.05f;
    static constexpr uint16_t HYST    = 20;

    void  init();
    void  poll();
    float get(uint8_t idx);  // 0.0–1.0

private:
    void     select_channel(uint8_t ch);
    uint16_t read_adc();

    float    smoothed_[NUM_POTS] = {};
    uint16_t last_raw_[NUM_POTS] = {};
};
