#include "audio_output_i2s.h"
#include "hardware/clocks.h"
#include "hardware/gpio.h"
#include "pico/stdlib.h"
#include "pcm5102_i2s.pio.h"

void AudioOutputI2S::init() {
    if (initialized_) return;

    gpio_init(PIN_DIN);
    gpio_init(PIN_BCLK);
    gpio_init(PIN_LRCK);

    pio_gpio_init(pio_, PIN_DIN);
    pio_gpio_init(pio_, PIN_BCLK);
    pio_gpio_init(pio_, PIN_LRCK);

    offset_ = pio_add_program(pio_, &pcm5102_i2s_program);
    sm_ = pio_claim_unused_sm(pio_, true);

    pio_sm_config c = pcm5102_i2s_program_get_default_config(offset_);
    sm_config_set_out_pins(&c, PIN_DIN, 1);
    sm_config_set_sideset_pins(&c, PIN_BCLK);
    sm_config_set_out_shift(&c, false, false, 32); // shift MSB first, manual pull
    sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);
    sm_config_set_clkdiv(&c, (float)clock_get_hz(clk_sys) / (SAMPLE_RATE * 32.0f * 2.0f));

    // Base pin for 2-bit sideset = BCLK, next pin = LRCK
    pio_sm_set_consecutive_pindirs(pio_, sm_, PIN_DIN, 1, true);
    pio_sm_set_consecutive_pindirs(pio_, sm_, PIN_BCLK, 2, true);
    pio_sm_init(pio_, sm_, offset_, &c);
    pio_sm_set_enabled(pio_, sm_, true);

    // Prime silence so the DAC PLL sees a valid stream immediately.
    for (int i = 0; i < 8; ++i) {
        pio_sm_put_blocking(pio_, sm_, 0u);
    }
    initialized_ = true;
}

void AudioOutputI2S::write(int16_t left, int16_t right) {
    // Pack stereo frame: L high 16, R low 16.
    const uint32_t l = (uint16_t)left;
    const uint32_t r = (uint16_t)right;
    const uint32_t frame = (l << 16) | r;
    pio_sm_put_blocking(pio_, sm_, frame);
}
