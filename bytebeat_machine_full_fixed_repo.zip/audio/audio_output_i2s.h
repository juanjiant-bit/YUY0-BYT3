#pragma once
// audio_output_i2s.h — PCM5102/PCM5102A backend para RP2040 usando PIO.
// Pines default:
//   GP10 = BCK
//   GP11 = LRCK / LCK / WS
//   GP12 = DIN
#include "audio_output.h"
#include "hardware/pio.h"

class AudioOutputI2S : public AudioOutput {
public:
    static constexpr uint8_t PIN_BCLK = 10;
    static constexpr uint8_t PIN_LRCK = 11;
    static constexpr uint8_t PIN_DIN  = 12;
    static constexpr uint32_t SAMPLE_RATE = 44100;

    void init() override;
    void write(int16_t left, int16_t right) override;
    void start() override {}
    void stop() override {}

private:
    PIO pio_ = pio0;
    uint sm_ = 0;
    uint offset_ = 0;
    bool initialized_ = false;
};
