// clock_out.cpp — V1.4.4
#include "clock_out.h"
#include "../utils/debug_log.h"

void ClockOut::init() {
    gpio_init(PIN);
    gpio_set_dir(PIN, GPIO_OUT);
    gpio_put(PIN, 0);
    alarm_id_ = -1;
}

void ClockOut::on_tick() {
    // Ignorar si pulso en curso
    if (gpio_get(PIN)) return;

    if (alarm_id_ >= 0) {
        cancel_alarm(alarm_id_);
        alarm_id_ = -1;
    }

    gpio_put(PIN, 1);
    alarm_id_ = add_alarm_in_us(PULSE_US, alarm_cb,
                                 static_cast<void*>(this), true);
}

int64_t ClockOut::alarm_cb(alarm_id_t, void* user_data) {
    gpio_put(PIN, 0);
    static_cast<ClockOut*>(user_data)->alarm_id_ = -1;
    return 0;
}
