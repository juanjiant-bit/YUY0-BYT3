#pragma once
// lead_osc.h — Bytebeat Machine V1.6
// Oscilador senoidal para el lead tonal cuantizado.
// Fase acumulada Q24 (mismo esquema que el kick).
// Seno de tabla 256 puntos — sin sinf() en hot path.
//
// INTEGRACIÓN:
//   LeadOsc vive en AudioEngine.
//   Cada sample: LeadOsc::set_freq(hz) si la frecuencia cambió,
//   luego LeadOsc::process() → int16_t.
//   El lead se mezcla con el bytebeat según quant_amount.
//
// VIBRATO (futuro): modular freq con LFO lento.
// PORTAMENTO: glide entre frecuencias por slew rate en set_freq().
//
#include <cstdint>
#include "bytebeat_node.h"  // SINE_TABLE está en drum_engine.h pero
                            // para no duplicar usamos la del drum

// Tabla seno Q15 256 puntos (definida en drum_engine.h como extern o inline)
// Para evitar duplicados, declaramos extern y la definimos en un .cpp
extern const int16_t SINE_TABLE_256[256];

class LeadOsc {
public:
    void init() { phase_q24_ = 0; freq_hz_ = 220.0f; delta_ = freq_to_delta(220.0f); }

    // Llamar cuando cambia la frecuencia (no necesariamente cada sample)
    void set_freq(float hz) {
        if (hz < 20.0f)   hz = 20.0f;
        if (hz > 8000.0f) hz = 8000.0f;
        freq_hz_ = hz;
        delta_   = freq_to_delta(hz);
    }

    // Portamento suave: slew hacia target_freq en ~20ms
    void set_freq_slew(float hz) {
        target_freq_ = hz;
        slew_active_ = true;
    }

    // process(): llamar cada sample. Retorna int16_t Q15.
    int16_t process() {
        // Portamento
        if (slew_active_) {
            float diff = target_freq_ - freq_hz_;
            if (diff > 0.5f || diff < -0.5f) {
                freq_hz_ += diff * SLEW_ALPHA;
                delta_    = freq_to_delta(freq_hz_);
            } else {
                freq_hz_  = target_freq_;
                slew_active_ = false;
                delta_    = freq_to_delta(freq_hz_);
            }
        }

        // Avance de fase Q24
        phase_q24_ += delta_;
        if (phase_q24_ >= 0x1000000u) phase_q24_ -= 0x1000000u;

        // Lookup seno Q15
        uint8_t  idx  = (uint8_t)(phase_q24_ >> 16);
        return SINE_TABLE_256[idx];
    }

    float get_freq() const { return freq_hz_; }

private:
    // freq_hz → delta Q24
    // delta = freq * (2^24 / 44100) = freq * 380.633...
    // En entero: freq * 380 (error 0.16% — aceptable para audio)
    static uint32_t freq_to_delta(float hz) {
        return (uint32_t)(hz * 380.633f);
    }

    // Slew alpha: cuánto se acerca cada sample
    // SLEW_ALPHA=0.002 → tau ≈ 500 samples ≈ 11ms @ 44100Hz
    static constexpr float SLEW_ALPHA = 0.002f;

    uint32_t phase_q24_   = 0;
    uint32_t delta_       = 0;
    float    freq_hz_     = 220.0f;
    float    target_freq_ = 220.0f;
    bool     slew_active_ = false;
};
